
var name = document.getElementById("first");
first.onclick = function(e)
{
	// 可通过preventDefault方法，来阻止URL跳转网页
	e.preventDefault();
	// innerHTML属性来修改，单击“传送门”后字体变为“穿越成功”
	first.innerHTML = "穿越成功";
}